function downloadVideo() {
  const url = document.getElementById("videoUrl").value;
  if (!url.includes("tiktok.com")) {
    alert("Please enter a valid TikTok URL");
    return;
  }

  const api = `https://api.savetiktok.cc/tiktok?url=${encodeURIComponent(url)}`;

  fetch(api)
    .then(res => res.json())
    .then(data => {
      if (data && data.video_no_watermark) {
        document.getElementById("result").innerHTML =
          `<a href="${data.video_no_watermark}" target="_blank">Click here to download video</a>`;
      } else {
        document.getElementById("result").innerText = "Download failed.";
      }
    })
    .catch(() => {
      document.getElementById("result").innerText = "Error occurred.";
    });
}