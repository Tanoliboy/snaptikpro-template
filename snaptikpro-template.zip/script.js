
document.getElementById("downloadForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const videoURL = document.getElementById("videoURL").value;
  const resultDiv = document.getElementById("result");
  resultDiv.innerHTML = "Fetching download link...";

  fetch(`https://api.tiklydown.me/api/download?url=${encodeURIComponent(videoURL)}`)
    .then(res => res.json())
    .then(data => {
      if (data?.video?.no_watermark) {
        resultDiv.innerHTML = \`<a href="\${data.video.no_watermark}" target="_blank" download>Click here to download video</a>\`;
      } else {
        resultDiv.innerHTML = "Failed to get download link. Please try another URL.";
      }
    })
    .catch(() => {
      resultDiv.innerHTML = "Something went wrong. Try again later.";
    });
});
